
file = open('col.txt', "r")
content:str = file.read()
file.close()
split: list[str] = content.split('\n')
splitq = []
for q in split:
    splitq.append(float(q))
file = open('col.txt', "w")
file.write(str(splitq))

file.close()