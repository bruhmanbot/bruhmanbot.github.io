async function loadFiles(){
    const fileInfo = await fetch('fileinfo.json')

    return fileInfo.json()
}

function addRowtoTable(values, tableId){
    // get table
    var table = document.getElementById(tableId);

    var row = table.insertRow(table.length)

    let counter = 0
    // insert values
    txt_values = values.slice(0, 3)

    for (ele of txt_values){
        cell = row.insertCell(counter);
        
        if (counter == 0) {
            const link_url = values[values.length-1]
            const anchor1 = "<a href=" + String(link_url) + ">"
            const cell0_txt = anchor1 + ele + "</a>"
            cell.innerHTML = cell0_txt
        }
        else {
            cell.innerHTML = ele;
        }
        counter ++
    }

}

function drawTable(entries, tableId) {
    let valuesQ
    for (q of Object.keys(entries)) {
        valuesQ = Object.values(entries[q])
        addRowtoTable(valuesQ, tableId)
    }

    return
}

async function main(){
    const fileInfo = await loadFiles()

    drawTable(fileInfo, "phys_tbl")

    return
}

main()

